import { Briefcase, Award, Heart } from "lucide-react";

export const AboutSection = () => {
  return (
    <section id="about" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-5xl">
        
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          About <span className="text-primary">Me</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          
          {/* LEFT SIDE */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold">
              Hi! I'm Sanni.
            </h3>

            <p className="text-muted-foreground">
              I'm a student at Bridgeland High School who enjoys combining
              creativity, leadership, business, and technology.
            </p>

            <p className="text-muted-foreground">
              Through FBLA, school organizations, volunteering, and design,
              I've had opportunities to challenge myself, work with others,
              and contribute to my community.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a href="#skills" className="cosmic-button">
                My Skills
              </a>

              <a
                href="#contact"
                className="px-6 py-2 rounded-full border border-primary text-primary hover:bg-primary/10 transition-colors duration-300"
              >
                Contact Me
              </a>
            </div>
          </div>

          {/* RIGHT SIDE */}
          <div className="grid grid-cols-1 gap-6">

            <div className="gradient-border p-6 card-hover">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Award className="h-6 w-6 text-primary" />
                </div>

                <div className="text-left">
                  <h4 className="font-semibold text-lg">
                    FBLA Graphic Design
                  </h4>
                  <p className="text-muted-foreground">
                    1st place in Texas and 3rd place nationally.
                  </p>
                </div>
              </div>
            </div>

            <div className="gradient-border p-6 card-hover">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Briefcase className="h-6 w-6 text-primary" />
                </div>

                <div className="text-left">
                  <h4 className="font-semibold text-lg">
                    Leadership
                  </h4>
                  <p className="text-muted-foreground">
                    Key Club Social Chair with experience organizing events
                    and supporting student organizations.
                  </p>
                </div>
              </div>
            </div>

            <div className="gradient-border p-6 card-hover">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Heart className="h-6 w-6 text-primary" />
                </div>

                <div className="text-left">
                  <h4 className="font-semibold text-lg">
                    Community Service
                  </h4>
                  <p className="text-muted-foreground">
                    60+ volunteer hours and involvement in community and
                    school service projects.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};