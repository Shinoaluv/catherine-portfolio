import { ArrowDown } from "lucide-react";
import sanniPhoto from "../assets/sanni.jpg";

export const HeroSection = () => {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center px-4 pt-24 overflow-hidden"
    >
      <div className="container max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        
        <div className="z-10 text-center md:text-left">
          <p className="text-sm md:text-base font-medium tracking-[0.25em] uppercase text-primary mb-4">
            Student • Leader • Designer
          </p>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
            Hi, I'm{" "}
            <span className="text-primary">
              Sanni Arimanda
            </span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-xl mb-8">
            I'm a student at Bridgeland High School passionate about design,
            leadership, business, technology, and making a positive impact in
            my community.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <a href="#about" className="cosmic-button">
              Explore My Portfolio
            </a>

            <a
              href="#contact"
              className="px-6 py-3 rounded-full border border-primary text-primary hover:bg-primary/10 transition-colors duration-300"
            >
              Contact Me
            </a>
          </div>
        </div>

        <div className="relative flex justify-center items-center">
          <div className="absolute w-[330px] h-[430px] md:w-[390px] md:h-[500px] leopard-bg rounded-[2rem] rotate-6 shadow-2xl"></div>

          <div className="relative w-[300px] h-[400px] md:w-[360px] md:h-[470px] rounded-[2rem] overflow-hidden shadow-2xl border-[8px] border-card -rotate-2 hover:rotate-0 hover:scale-[1.02] transition-all duration-500">
            <img
              src={sanniPhoto}
              alt="Sanni Arimanda"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce">
        <span className="text-sm text-muted-foreground mb-2">
          Scroll
        </span>

        <ArrowDown className="h-5 w-5 text-primary" />
      </div>
    </section>
  );
};