import { Mail, MapPin, Send } from "lucide-react";

export const ContactSection = () => {
  return (
    <section id="contact" className="py-24 px-4 relative bg-secondary/30">
      <div className="container mx-auto max-w-5xl">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Get In <span className="text-primary">Touch</span>
        </h2>

        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Thanks for visiting my portfolio. I’m always excited to learn,
          collaborate, and take on new opportunities.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* CONTACT INFO */}
          <div className="space-y-6">
            <div className="gradient-border p-6 card-hover">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Mail className="h-6 w-6 text-primary" />
                </div>

                <div className="text-left">
                  <h3 className="font-semibold text-lg">Email</h3>
                  <a
                    href="mailto:sanni.arimanda08@gmail.com"
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    sanni.arimanda08@gmail.com
                  </a>
                </div>
              </div>
            </div>

            <div className="gradient-border p-6 card-hover">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>

                <div className="text-left">
                  <h3 className="font-semibold text-lg">Location</h3>
                  <p className="text-muted-foreground">
                    Cypress, Texas
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* SIMPLE CONTACT FORM */}
          <div className="bg-card p-8 rounded-lg shadow-xs">
            <h3 className="text-2xl font-semibold mb-6 text-left">
              Send a Message
            </h3>

            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2 text-left">
                  Name
                </label>

                <input
                  type="text"
                  placeholder="Your name"
                  className="w-full px-4 py-3 rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-left">
                  Email
                </label>

                <input
                  type="email"
                  placeholder="Your email"
                  className="w-full px-4 py-3 rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-left">
                  Message
                </label>

                <textarea
                  rows="4"
                  placeholder="Your message"
                  className="w-full px-4 py-3 rounded-md border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                />
              </div>

              <button
                type="button"
                className="cosmic-button w-full flex items-center justify-center gap-2"
              >
                Send Message
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};