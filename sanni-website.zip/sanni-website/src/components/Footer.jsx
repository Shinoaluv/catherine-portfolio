import { ArrowUp } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-8 px-4 border-t border-border bg-background">
      <div className="container mx-auto max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-4">
        
        <p className="text-sm text-muted-foreground text-center sm:text-left">
          © 2026 Sanni Arimanda. All rights reserved.
        </p>

        <a
          href="#hero"
          className="flex items-center gap-2 text-sm font-medium text-primary hover:opacity-80 transition-opacity"
        >
          Back to top
          <ArrowUp className="h-4 w-4" />
        </a>
      </div>
    </footer>
  );
};