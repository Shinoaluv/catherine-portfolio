import { Navbar } from "../components/Navbar";
import { HeroSection } from "../components/HeroSection";
import { AboutSection } from "../components/AboutSection";
import { SkillsSection } from "../components/SkillsSection";
import { ContactSection } from "../components/ContactSection";
import { ThemeToggle } from "../components/ThemeToggle";
import { Footer } from "../components/Footer";
import leopardBg from "../assets/leopard-bg.jpg";

export const Home = () => {
  return (
    <div
      className="website-background min-h-screen text-foreground overflow-x-hidden"
      style={{
        backgroundImage: `url(${leopardBg})`,
      }}
    >
      <ThemeToggle />
      <Navbar />

      <main>
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <ContactSection />
      </main>

      <Footer />
    </div>
  );
};